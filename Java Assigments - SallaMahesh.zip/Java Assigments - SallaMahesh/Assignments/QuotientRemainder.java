package com.lab1.exercises;

public class QuotientRemainder {

	public static void main(String[] args) {
		
		int a=11;
		int b=3;
		
		int quotient=a/b;
		System.out.println(quotient);
		
		int reminder=a%b;
		System.out.println(reminder);
		

	}

}
