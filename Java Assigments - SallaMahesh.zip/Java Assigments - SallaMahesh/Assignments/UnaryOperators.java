package com.lab1.exercises;

public class UnaryOperators {

	public static void main(String[] args) {
		
		int a=10;
		int b=5;
		
		int add=a+b;
		System.out.println(add);
		
		int sub=a-b;
		System.out.println(sub);
		
		int mul=a*b;
		System.out.println(mul);
		
		int div=a/b;
		System.out.println(div);
		
		a=16;
		b=3;
		int rad=a%b;
		System.out.println(rad);
	

	}

}
